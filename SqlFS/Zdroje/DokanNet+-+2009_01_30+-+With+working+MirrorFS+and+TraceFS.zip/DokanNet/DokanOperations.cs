using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;

namespace Dokan
{
    public class DokanFileInfo
    {
        public Object Context;
        public bool IsDirectory;
        public ulong InfoId;
        public uint ProcessId;

        public DokanFileInfo()
        {
            Context = null;
            IsDirectory = false;
            InfoId = 0;
        }

        public override string ToString()
        {
            return string.Format("Context: {0} PID: {1}", Context, ProcessId);
        }
    }


    public class FileInformation
    {
        public FileAttributes Attributes;
        public DateTime CreationTime;
        public DateTime LastAccessTime;
        public DateTime LastWriteTime;
        public long Length;
        public string FileName;

        public void Copy(FileInformation other)
        {
            this.Attributes = other.Attributes;
            this.CreationTime = other.CreationTime;
            this.LastAccessTime = other.LastAccessTime;
            this.LastWriteTime = other.LastWriteTime;
            this.Length = other.Length;
            this.FileName = other.FileName;
        }
    }

    public interface DokanOperations
    {
        int CreateFile(
                string filename,
                FileAccess access,
                FileShare share,
                FileMode mode,
                FileOptions options,
                DokanFileInfo info);

        int OpenDirectory(
                string filename,
                DokanFileInfo info);

        int CreateDirectory(
                string filename,
                DokanFileInfo info);

        int Cleanup(
                string filename,
                DokanFileInfo info);

        int CloseFile(
                string filename,
                DokanFileInfo info);

        int ReadFile(
                string filename,
                byte[] buffer,
                ref uint readBytes,
                long offset,
                DokanFileInfo info);

        int WriteFile(
                string filename,
                byte[] buffer,
                ref uint writtenBytes,
                long offset,
                DokanFileInfo info);

        int FlushFileBuffers(
                string filename,
                DokanFileInfo info);

        int GetFileInformation(
                string filename,
                FileInformation fileinfo,
                DokanFileInfo info);

        int FindFiles(
                string filename,
                List<FileInformation> files,
                DokanFileInfo info);

        int SetFileAttributes(
                string filename,
                FileAttributes attr,
                DokanFileInfo info);

        int SetFileTime(
                string filename,
                DateTime ctime,
                DateTime atime,
                DateTime mtime,
                DokanFileInfo info);

        int DeleteFile(
                string filename,
                DokanFileInfo info);

        int DeleteDirectory(
                string filename,
                DokanFileInfo info);

        int MoveFile(
                string filename,
                string newname,
                bool replace,
                DokanFileInfo info);

        int SetEndOfFile(
                string filename,
                long length,
                DokanFileInfo info);

        int LockFile(
                string filename,
                long offset,
                long length,
                DokanFileInfo info);

        int UnlockFile(
                string filename,
                long offset,
                long length,
                DokanFileInfo info);

        int GetDiskFreeSpace(
                ref ulong freeBytesAvailable,
                ref ulong totalBytes,
                ref ulong totalFreeBytes,
                DokanFileInfo info);

        int Unmount(
                DokanFileInfo info);

    }
}
