﻿using System;

namespace Dokan
{
    public interface IDokanProxy
    {
        int CleanupProxy(IntPtr FileName, ref DOKAN_FILE_INFO FileInfo);
        int CloseFileProxy(IntPtr FileName, ref DOKAN_FILE_INFO FileInfo);
        int CreateDirectoryProxy(IntPtr FileName, ref DOKAN_FILE_INFO FileInfo);
        int CreateFileProxy(IntPtr FileName, uint AccessMode, uint Share, uint CreationDisposition, uint FlagsAndAttributes, ref DOKAN_FILE_INFO FileInfo);
        int DeleteDirectoryProxy(IntPtr FileName, ref DOKAN_FILE_INFO FileInfo);
        int DeleteFileProxy(IntPtr FileName, ref DOKAN_FILE_INFO FileInfo);
        int FindFilesProxy(IntPtr FileName, IntPtr FillFindData, ref DOKAN_FILE_INFO FileInfo);
        int FlushFileBuffersProxy(IntPtr FileName, ref DOKAN_FILE_INFO FileInfo);
        int GetDiskFreeSpaceProxy(ref ulong FreeBytesAvailable, ref ulong TotalNumberOfBytes, ref ulong TotalNumberOfFreeBytes, ref DOKAN_FILE_INFO FileInfo);
        int GetFileInformationProxy(IntPtr FileName, ref BY_HANDLE_FILE_INFORMATION HandleFileInformation, ref DOKAN_FILE_INFO FileInfo);
        int GetVolumeInformationProxy(IntPtr VolumeNameBuffer, uint VolumeNameSize, ref uint VolumeSerialNumber, ref uint MaximumComponentLength, ref uint FileSystemFlags, IntPtr FileSystemNameBuffer, uint FileSystemNameSize, ref DOKAN_FILE_INFO FileInfo);
        int LockFileProxy(IntPtr FileName, long ByteOffset, long Length, ref DOKAN_FILE_INFO FileInfo);
        int MoveFileProxy(IntPtr FileName, IntPtr NewFileName, int ReplaceIfExisting, ref DOKAN_FILE_INFO FileInfo);
        int OpenDirectoryProxy(IntPtr fileName, ref DOKAN_FILE_INFO fileInfo);
        int ReadFileProxy(IntPtr FileName, IntPtr Buffer, uint BufferLength, ref uint ReadLength, long Offset, ref DOKAN_FILE_INFO FileInfo);
        int SetEndOfFileProxy(IntPtr FileName, long ByteOffset, ref DOKAN_FILE_INFO FileInfo);
        int SetFileAttributesProxy(IntPtr FileName, uint Attributes, ref DOKAN_FILE_INFO FileInfo);
        int SetFileTimeProxy(IntPtr FileName, ref System.Runtime.InteropServices.ComTypes.FILETIME CreationTime, ref System.Runtime.InteropServices.ComTypes.FILETIME LastAccessTime, ref System.Runtime.InteropServices.ComTypes.FILETIME LastWriteTime, ref DOKAN_FILE_INFO FileInfo);
        int UnlockFileProxy(IntPtr FileName, long ByteOffset, long Length, ref DOKAN_FILE_INFO FileInfo);
        int UnmountProxy(ref DOKAN_FILE_INFO FileInfo);
        int WriteFileProxy(IntPtr FileName, IntPtr Buffer, uint NumberOfBytesToWrite, ref uint NumberOfBytesWritten, long Offset, ref DOKAN_FILE_INFO FileInfo);
    }
}
