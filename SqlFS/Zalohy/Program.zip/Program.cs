using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Win32;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;
using Dokan;

namespace SqlFS
{
    class MSSQLFS : DokanOperations
    {

        SqlBinary mem;
        string ConnectionString;

        #region DokanOperations member

       
        public MSSQLFS()
        {
            ConnectionString = "Data Source=kmrn02.d30.intra;Initial Catalog=ekvelb2;Integrated Security=False;User ID=nedopilm;Password=Sestpet4;Pooling=true;Min Pool Size=10;Max Pool Size=40;Connect Timeout=100";
        }

        #region Directory function
        public int CreateDirectory(string filename, DokanFileInfo info)
        {
            //create directory in database
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                SqlCommand SP = new SqlCommand();
                SP.Connection = conn;
                SP.CommandType = CommandType.StoredProcedure;
                SP.CommandText = "CreateDirectory";
                SP.Parameters.AddWithValue("@filename", filename);
                conn.Open();
                SP.ExecuteNonQuery();
            }
            return 0;
        }

        public int DeleteDirectory(string filename, DokanFileInfo info)
        {
            return -1;
        }

        public int OpenDirectory(string filename, DokanFileInfo info)
        {
            return 0;
        }

        #endregion

        public int Cleanup(string filename, DokanFileInfo info)
        {
            //todo: clear all lock table
            return 0;
        }

        public int CloseFile(string filename, DokanFileInfo info)
        {
            //todo: clear lock table for file
            return 0;
        }


        public int CreateFile(
            string filename,
            System.IO.FileAccess access,
            System.IO.FileShare share,
            System.IO.FileMode mode,
            System.IO.FileOptions options,
            DokanFileInfo info)
        {
            if (access == System.IO.FileAccess.Write)
            {
                if (mode == System.IO.FileMode.OpenOrCreate)
                {
                    return 0;
                }
            }
            return 0;
        }


        public int DeleteFile(string filename, DokanFileInfo info)
        {
            return -1;
        }



        public int FlushFileBuffers(
            string filename,
            DokanFileInfo info)
        {
            return -1;
        }


        public int FindFiles(
            string filename,
            System.Collections.ArrayList files,
            DokanFileInfo info)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {

                SqlCommand Cmd = new SqlCommand();
                Cmd.CommandText = "FindFiles";
                Cmd.Parameters.AddWithValue("@filename", filename);
                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Connection = conn;
                conn.Open();
                using (SqlDataReader reader = Cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        FileInformation finfo = new FileInformation();
                        finfo.FileName = reader[0].ToString();
                        finfo.Attributes = reader[1].ToString() == "True" ? System.IO.FileAttributes.Directory : System.IO.FileAttributes.Normal;
                        finfo.LastAccessTime = DateTime.Now;
                        finfo.LastWriteTime = DateTime.Now;
                        finfo.CreationTime = DateTime.Now;
                        finfo.Length = (reader[2] is DBNull) ? 0 : int.Parse(reader[2].ToString()); ///TODO
                        files.Add(finfo);
                    }
                }
                conn.Close();
            }
            return 0;
        }


        public int GetFileInformation(
            string filename,
            FileInformation fileinfo,
            DokanFileInfo info)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand Cmd = new SqlCommand())
                {
                    Cmd.CommandText = "GetFileInformation";
                    Cmd.Parameters.AddWithValue("@filename", filename);
                    Cmd.Parameters.Add("@IsDirectory", SqlDbType.Bit);
                    Cmd.Parameters["@IsDirectory"].Direction = ParameterDirection.Output;
                    Cmd.Parameters.Add("@Length", SqlDbType.BigInt);
                    Cmd.Parameters["@Length"].Direction = ParameterDirection.Output;
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Connection = conn;
                    conn.Open();

                    Cmd.ExecuteNonQuery();

                    if (Cmd.Parameters["@Length"].Value == null)
                    {
                        return -1;
                    }

                    fileinfo.Attributes = (Cmd.Parameters["@IsDirectory"].Value.ToString() == "True") ? System.IO.FileAttributes.Directory : System.IO.FileAttributes.Normal;
                    fileinfo.LastAccessTime = DateTime.Now;
                    fileinfo.LastWriteTime = DateTime.Now;
                    fileinfo.CreationTime = DateTime.Now;
                    fileinfo.Length = Cmd.Parameters["@Length"].Value is System.DBNull ? 0 : (Int64)Cmd.Parameters["@Length"].Value;
                }
            }
            return 0;
        }

        public int LockFile(
            string filename,
            long offset,
            long length,
            DokanFileInfo info)
        {
            return 0;
        }

        public int MoveFile(
            string filename,
            string newname,
            bool replace,
            DokanFileInfo info)
        {
            return -1;
        }



        public int ReadFile(
            string filename,
            byte[] buffer,
            ref uint readBytes,
            long offset,
            DokanFileInfo info)
        {
            mem = new SqlBinary();

            long readed = -1;
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                SqlCommand Cmd = new SqlCommand();
                Cmd.CommandText = "ReadFile";
                Cmd.Parameters.AddWithValue("@filename", filename);
                Cmd.Parameters.AddWithValue("@offset", offset);

                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Connection = conn;
                conn.Open();
                using (SqlDataReader reader = Cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        readed = (long)reader[0];
                        mem = reader.GetSqlBinary(1);
                    }
                }

                //
                if (offset >= readed)
                {
                    readBytes = 0;
                    return -1;
                }
                Buffer.BlockCopy(mem.Value, 0, buffer, 0, Math.Min(buffer.Length, mem.Length));
                readBytes = (uint)readed;
            }
            return 0;
        }

        public int SetEndOfFile(string filename, long length, DokanFileInfo info)
        {
            return -1;
        }

        public int SetAllocationSize(string filename, long length, DokanFileInfo info)
        {
            return -1;
        }

        public int SetFileAttributes(
            string filename,
            System.IO.FileAttributes attr,
            DokanFileInfo info)
        {
            return -1;
        }

        public int SetFileTime(
            string filename,
            DateTime ctime,
            DateTime atime,
            DateTime mtime,
            DokanFileInfo info)
        {
            return -1;
        }

        public int UnlockFile(string filename, long offset, long length, DokanFileInfo info)
        {
            return 0;
        }

        public int Unmount(DokanFileInfo info)
        {
            return 0;
        }

        public int GetDiskFreeSpace(
           ref ulong freeBytesAvailable,
           ref ulong totalBytes,
           ref ulong totalFreeBytes,
           DokanFileInfo info)
        {
            freeBytesAvailable = 512 * 1024 * 1024;
            totalBytes = 1024 * 1024 * 1024;
            totalFreeBytes = 512 * 1024 * 1024;
            return 0;
        }

        public int WriteFile(
            string filename,
            byte[] buffer,
            ref uint writtenBytes,
            long offset,
            DokanFileInfo info)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand Cmd = new SqlCommand())
                {
                    Cmd.CommandText = "WriteFile";
                    Cmd.Parameters.AddWithValue("@filename", filename);
                    Cmd.Parameters.Add("@data", SqlDbType.VarBinary, buffer.Length);
                    Cmd.Parameters["@data"].SqlValue = buffer;

                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Connection = conn;
                    conn.Open();

                    Cmd.ExecuteNonQuery();
                }
            }

            return 0;
        }

        #endregion
    }

    class Program
    {
        static void Main(string[] args)
        {
            DokanOptions opt = new DokanOptions();
            opt.DriveLetter = 'r';
            opt.DebugMode = true;
            opt.UseAltStream = false;
            opt.UseKeepAlive = false;
            opt.UseStdErr = true;
            opt.VolumeLabel = "MSSQLFS";
            opt.DebugMode = false;
            DokanNet.DokanMain(opt, new MSSQLFS());
        }
    }
}
